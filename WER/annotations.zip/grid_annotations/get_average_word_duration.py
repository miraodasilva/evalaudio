import os
import csv
import numpy as np

durations = []

for root,dirs,files in os.walk("."):
	for name in files:
		file = os.path.join(root,name)
		if not file.endswith(".align"):
			continue
		with open(file, 'r') as csvfile:
			annotation_reader = csv.reader(csvfile, delimiter=' ', quotechar='|')
			for row in annotation_reader:
				start = int(row[0])
				end = int(row[1])
				durations += [end-start]

print(durations)
avg_duration = np.array(durations).mean()
print(avg_duration/25000)
